// components/public/Footer.jsx
'use client';
import Link from "next/link";

export default function Footer() {
  return (
    <footer className="bg-black text-white py-10 px-6 mt-20">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-10">
        
        {/* Logo & About */}
        <div>
          <h2 className="text-2xl font-bold text-cyan-400 mb-4">Ramanth</h2>
        
        </div>

        {/* Links */}
        <div>
          <h3 className="text-xl font-semibold text-cyan-300 mb-4">Quick Links</h3>
          <ul className="space-y-2 text-gray-400">
            <li><Link href="/" className="hover:text-cyan-400">Home</Link></li>
            <li><Link href="/services" className="hover:text-cyan-400">Services</Link></li>
            <li><Link href="/projects" className="hover:text-cyan-400">Projects</Link></li>
            <li><Link href="/contact" className="hover:text-cyan-400">Contact</Link></li>
          </ul>
        </div>

        {/* Contact Info */}
        <div>
          <h3 className="text-xl font-semibold text-cyan-300 mb-4">Contact Us</h3>
          <p className="text-gray-400">📍 Mumbai, India</p>
          <p className="text-gray-400">📧 contact@ramanth.com</p>
          <p className="text-gray-400">📞 +91 98765 43210</p>
        </div>
      </div>

      {/* Bottom line */}
      <div className="mt-10 text-center text-gray-500 text-sm border-t border-gray-700 pt-4">
        &copy; {new Date().getFullYear()} Ramanth. All rights reserved.
      </div>
    </footer>
  );
}
