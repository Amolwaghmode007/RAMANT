// app/about/page.jsx
"use client";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { FaLinkedin, FaGithub, FaTwitter } from "react-icons/fa";
import Image from "next/image";
import { useLottie } from "lottie-react";
import animationData from "../../../public/animations/aboutus.json";

const profiles = [
  {
    name: "Suraj Bhandare",
    role: "CEO",
    image: "/images/ceo.jpg",
    bio: "Visionary leader with a passion for building impactful digital products.",
    links: {
      linkedin: "https://linkedin.com/in/nikhil",
      github: "https://github.com/nikhil",
      twitter: "https://twitter.com/nikhil",
    },
  },
  {
    name: "Rahul Mehta",
    role: "CFO",
    image: "/images/cfo.jpg",
    bio: "Financial strategist ensuring our growth is smart and scalable.",
    links: {
      linkedin: "https://linkedin.com/in/rahul",
      github: "https://github.com/rahul",
      twitter: "https://twitter.com/rahul",
    },
  },
  {
    name: "Sneha Patil",
    role: "Developer",
    image: "/images/dev.jpg",
    bio: "Frontend engineer turning ideas into interactive experiences.",
    links: {
      linkedin: "https://linkedin.com/in/sneha",
      github: "https://github.com/sneha",
      twitter: "https://twitter.com/sneha",
    },
  },
];

export default function AboutUs() {
  const [index, setIndex] = useState(0);
  const profile = profiles[index];

  const nextProfile = () => setIndex((index + 1) % profiles.length);
  const prevProfile = () => setIndex((index - 1 + profiles.length) % profiles.length);

  const options = {
    animationData,
    loop: true,
    autoplay: true,
    style: { height: 500, width: 500 },
  };
  const { View: LottieView } = useLottie(options);
console.log("Lottie View:", LottieView);


  return (
    <section className="min-h-screen bg-gradient-to-tr from-white to-blue-50 py-10 px-4">
      <motion.div
        className="text-center mb-12"
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
      >
        <h1 className="text-4xl font-bold text-blue-700 mb-3">About Us</h1>
        <p className="text-gray-600 max-w-xl mx-auto">
          We're a team of passionate professionals dedicated to building beautiful and useful digital products.
        </p>
      </motion.div>

      {/* Main horizontal section */}
      <div className="flex flex-col md:flex-row items-center justify-center gap-10">
        {/* Left: Animation */}
        <div className="flex justify-center items-center mr-10">{LottieView}</div>

        {/* Right: Profile Card */}
        <div className="flex flex-col items-center relative">
          <AnimatePresence mode="wait">
            <motion.div
              key={profile.name}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.5 }}
              className="bg-white shadow-xl rounded-3xl p-8 text-center max-w-sm w-full"
            >
              <div className="w-32 h-32 mx-auto mb-4 rounded-full overflow-hidden border-4 border-blue-500">
                <Image src={profile.image} alt={profile.name} width={128} height={128} className="object-cover" />
              </div>
              <h2 className="text-xl font-semibold text-blue-800 mb-1">{profile.name}</h2>
              <p className="text-sm text-blue-500 mb-2">{profile.role}</p>
              <p className="text-gray-600 text-sm mb-4">{profile.bio}</p>
              <div className="flex justify-center gap-4">
                <a href={profile.links.linkedin} target="_blank" className="text-blue-700 hover:text-blue-900 transition text-xl"><FaLinkedin /></a>
                <a href={profile.links.github} target="_blank" className="text-gray-800 hover:text-black transition text-xl"><FaGithub /></a>
                <a href={profile.links.twitter} target="_blank" className="text-blue-400 hover:text-blue-600 transition text-xl"><FaTwitter /></a>
              </div>
              <div className="absolute inset-y-1/2 -left-10 flex items-center">
                <button onClick={prevProfile} className="bg-blue-200 hover:bg-blue-300 p-2 rounded-full shadow">
                  &#8592;
                </button>
              </div>
              <div className="absolute inset-y-1/2 -right-10 flex items-center">
                <button onClick={nextProfile} className="bg-blue-200 hover:bg-blue-300 p-2 rounded-full shadow">
                  &#8594;
                </button>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}
