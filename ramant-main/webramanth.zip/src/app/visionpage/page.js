import { useEffect, useState } from "react";
import { useLottie } from "lottie-react";

export default function VisionMission() {
  const [visionOptions, setVisionOptions] = useState(null);
  const [missionOptions, setMissionOptions] = useState(null);

  useEffect(() => {
    // Fetch vision.json
    fetch("/animations/vision.json")
      .then((res) => res.json())
      .then((data) => {
        setVisionOptions({
          animationData: data,
          loop: true,
          autoplay: true,
          style: { height: 100, width: 100 },
        });
      });

    // Fetch mission.json
    fetch("/animations/mission.json")
      .then((res) => res.json())
      .then((data) => {
        setMissionOptions({
          animationData: data,
          loop: true,
          autoplay: true,
          style: { height: 100, width: 100 },
        });
      });
  }, []);

  const visionLottie = useLottie(visionOptions || {});
  const missionLottie = useLottie(missionOptions || {});

  return (
    <section className="relative min-h-screen w-full flex items-center justify-center bg-white px-4 py-12">
      {/* Vertical Line - show only on medium and up */}
      <div className="absolute w-[2px] h-[70%] bg-black left-1/2 transform -translate-x-1/2 hidden md:block" />

      {/* Top Left - Vision Heading + Animation */}
      <div className="absolute top-[18%] left-1/4 transform -translate-x-1/2 -translate-y-1/2 text-center">
        <h2 className="text-xl md:text-3xl font-bold text-blue-500">our vision</h2>
        <div className="mt-2">{visionLottie.View}</div>
      </div>

      {/* Top Right - Horizontal Line + Vision Description */}
      <div className="absolute top-1/4 left-1/2 transform -translate-y-1/2 h-[2px] w-[110px] bg-black hidden md:block" />
      <div className="absolute top-1/4 right-1/4 transform translate-x-1/2 -translate-y-1/2 text-center max-w-xs md:max-w-sm">
        <p className="text-sm md:text-base text-gray-700">
          Empowering businesses through smart, scalable, and innovative digital solutions.
          We envision a future where every business, regardless of size, leverages modern
          technology to grow, connect, and create impact.
        </p>
      </div>

      {/* Bottom Left - Horizontal Line + Mission Description */}
      <div className="absolute bottom-1/4 right-1/2 transform translate-y-1/2 h-[2px] w-[110px] bg-black hidden md:block" />
      <div className="absolute bottom-1/4 left-1/4 transform -translate-x-1/2 translate-y-1/2 text-center max-w-xs md:max-w-sm">
        <p className="text-sm md:text-base text-gray-700">
          At Ramanth, our mission is to deliver high-quality, customized web and mobile applications
          that solve real-world problems. We aim to partner with startups and enterprises, providing them
          with cutting-edge design, reliable development, and end-to-end support — from concept to launch.
        </p>
      </div>

      {/* Bottom Right - Mission Heading + Animation */}
      <div className="absolute bottom-[18%] right-1/4 transform translate-x-1/2 translate-y-1/2 text-center">
        <h2 className="text-xl md:text-3xl font-bold text-blue-500 mb-2">our mission</h2>
        <div>{missionLottie.View}</div>
      </div>
    </section>
  );
}
