'use client';
import ServiceCard from '../components/public/ServiceCard';

export default function Services() {
  const services = [
    {
      title: "Web Development",
      animationPath: "/animations/web.json",
      description: "Responsive, high-performance websites with modern technologies.",
    },
    {
      title: "Mobile App Development",
      animationPath: "/animations/app.json",
      description: "Cross-platform mobile apps for Android and iOS.",
    },
    {
      title: "UI/UX Design",
      animationPath: "/animations/design.json",
      description: "Beautiful and intuitive designs to enhance user experience.",
    },
  ];

  return (
    <section className=" text-white bg-white py-20 px-6 min-h-screen">
      <h2 className="text-4xl font-bold text-center mb-12 text-black">
        Our Services
      </h2>
      <div className="flex flex-wrap justify-center gap-10 ">
        {services.map((service, i) => (
          <ServiceCard key={i} {...service} />
        ))}
      </div>
    </section>
  );
}
