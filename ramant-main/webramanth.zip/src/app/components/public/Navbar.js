import Image from "next/image";
import { useState, useEffect } from "react";

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const toggleMenu = () => setIsOpen(!isOpen);

  return (
    <nav
      className={`fixed w-full top-0 left-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-white shadow-md backdrop-blur-md"
          : "bg-white backdrop-blur-sm"
      }`}
    >
      <div className="max-w-7xl mx-auto flex justify-between items-center px-6 py-4">
        {/* Logo */}
        <div className="flex items-center gap-1 cursor-pointer select-none">
          <Image
            src="/logo2.png"
            alt="Logo"
            width={120}
            height={90}
            className="object-contain mt-1 ml-5"
          />
        </div>

        {/* Desktop Menu */}
        <ul className="hidden md:flex space-x-10 text-black font-semibold">
          {["Home", "Services", "Projects", "AboutUs", "Contact"].map((item) => (
            <li
              key={item}
              className="hover:text-cyan-500 transition-colors cursor-pointer relative group"
            >
              {item}
              <span className="block h-0.5 bg-cyan-500 scale-x-0 group-hover:scale-x-100 transition-transform origin-left absolute bottom-[-6px] left-0 right-0"></span>
            </li>
          ))}
        </ul>

        {/* Mobile Hamburger */}
        <button
          onClick={toggleMenu}
          aria-label="Toggle menu"
          className="md:hidden flex flex-col justify-center cursor-pointer focus:outline-none"
        >
          <span
            className={`block w-7 h-0.5 bg-cyan-500 mb-1 rounded transition-transform origin-center ${
              isOpen ? "rotate-45 translate-y-1.5" : ""
            }`}
          ></span>
          <span
            className={`block w-7 h-0.5 bg-cyan-500 mb-1 rounded transition-opacity ${
              isOpen ? "opacity-0" : "opacity-100"
            }`}
          ></span>
          <span
            className={`block w-7 h-0.5 bg-cyan-500 rounded transition-transform origin-center ${
              isOpen ? "-rotate-45 -translate-y-1.5" : ""
            }`}
          ></span>
        </button>
      </div>

      {/* Mobile Menu */}
      <div
        className={`md:hidden bg-white/90 backdrop-blur-md absolute w-full left-0 top-full overflow-hidden transition-max-height duration-300 ease-in-out ${
          isOpen ? "max-h-60" : "max-h-0"
        }`}
      >
        <ul className="flex flex-col px-6 py-4 space-y-4 text-black font-semibold">
          {["Home", "Services", "Projects", "AboutUs", "Contact"].map((item) => (
            <li
              key={item}
              className="hover:text-cyan-500 cursor-pointer"
              onClick={() => setIsOpen(false)}
            >
              {item}
            </li>
          ))}
        </ul>
      </div>
    </nav>
  );
}
