'use client';
import { useState } from "react";
import { motion } from "framer-motion";
import { useLottie } from "lottie-react";
import animationData from "@/animations/contactus.json"; // NOT from public

export default function ContactUs() {
  const [formData, setFormData] = useState({ name: "", email: "", message: "" });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Submitted:", formData);
  };

  const options = {
    animationData,
    loop: true,
    autoplay: true,
    style: { height: 350 },
  };

  const { View: LottieView } = useLottie(options);

  return (
    <section className="min-h-screen bg-gradient-to-tr from-white to-blue-50 py-16 px-6">
      <motion.h2
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="text-4xl font-bold text-blue-700 text-center mb-12"
      >
        Contact Us
      </motion.h2>

      <div className="flex flex-col lg:flex-row items-center justify-center gap-20">
        {/* Contact Form */}
        <motion.form
          onSubmit={handleSubmit}
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
          className="bg-white shadow-2xl rounded-3xl p-8 max-w-md w-full"
        >
          <div className="mb-3">
            <label className="block text-black mb-1">Name</label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              required
              className="w-full text-black border border-gray-300 rounded-xl px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-300"
            />
          </div>
          <div className="mb-3">
            <label className="block text-black mb-1">Email</label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              required
              className="w-full border text-black border-gray-300 rounded-xl px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-300"
            />
          </div>
          <div className="mb-4">
            <label className="block text-black mb-1">Message</label>
            <textarea
              name="message"
              value={formData.message}
              onChange={handleChange}
              required
              className="w-full border text-black border-gray-300 rounded-xl px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-300"
              rows="3"
            ></textarea>
          </div>

          {/* Buttons Section */}
          <div className="flex flex-col sm:flex-row sm:items-center gap-4">
            <button
              type="submit"
              className="bg-blue-600 text-white px-6 py-2 rounded-xl hover:bg-blue-700 transition w-full sm:w-auto"
            >
              Send Message
            </button>

            <a
              href="https://wa.me/917620341043?text=Hi%20there!%20I%20visited%20your%20website%20and%20want%20to%20connect."
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 bg-green-500 text-white px-6 py-2 rounded-xl hover:bg-green-600 transition w-full sm:w-auto"
            >
              {/* WhatsApp SVG Icon */}
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="currentColor"
                viewBox="0 0 448 512"
                className="w-5 h-5"
              >
                <path d="M380.9 97.1C339 55.3 282.5 32 222.3 32c-118.6 0-215 96.4-215 215 0 37.8 9.9 74.7 28.7 107.2L4.2 480l129.2-34c30.4 16.7 64.6 25.6 99 25.6h.1c118.5 0 215-96.5 215-215 0-60.2-23.4-116.7-66.6-158.9zM222.3 438.7c-27.6 0-54.7-7.3-78.4-21.1l-5.6-3.3-76.7 20.2 20.4-74.8-3.7-5.8C59 317.3 49.3 285.7 49.3 247c0-95.4 77.6-173 173-173 46.2 0 89.6 18 122.2 50.8 32.6 32.7 50.5 76.1 50.5 122.3 0 95.5-77.5 172.9-172.7 172.9zm101.7-138.7c-5.6-2.8-33.2-16.3-38.4-18.1-5.2-1.9-9-2.8-12.8 2.8s-14.7 18.1-18.1 21.9c-3.3 3.8-6.7 4.2-12.3 1.4-33.4-16.7-55.3-29.8-77.4-67.2-5.8-10 5.8-9.3 16.7-30.9 1.9-3.8.9-7.1-.5-9.9-1.4-2.8-12.8-30.9-17.6-42.3-4.6-11.1-9.3-9.6-12.8-9.8-3.3-.2-7.1-.2-10.9-.2s-10 1.4-15.2 7c-5.2 5.6-19.9 19.4-19.9 47.3s20.4 54.9 23.2 58.6c2.8 3.8 39.9 61 96.7 85.5 13.5 5.8 24 9.3 32.2 11.9 13.5 4.3 25.8 3.7 35.5 2.2 10.8-1.6 33.2-13.6 37.9-26.8 4.7-13.2 4.7-24.5 3.3-26.8-1.4-2.3-5.2-3.7-10.8-6.5z"/>
              </svg>
              WhatsApp
            </a>
          </div>
        </motion.form>

        {/* Lottie Animation */}
        <motion.div
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-md w-full"
        >
          {LottieView}
        </motion.div>
      </div>
    </section>
  );
}
