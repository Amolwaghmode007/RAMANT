import Link from "next/link";

export default function Projects() {
  return (
    <section className="min-h-screen bg-white py-12 px-4 flex flex-col items-center justify-center">
      <h1 className="text-3xl md:text-4xl font-bold mb-10 text-center text-blue-700">
        Our Projects
      </h1>

      <div className="w-full max-w-2xl bg-gradient-to-r from-white to-blue-50 shadow-xl rounded-2xl overflow-hidden flex flex-col items-center transition-transform hover:scale-[1.02] duration-300">
        {/* Project Image */}
        <div className="w-full h-64 md:h-96 bg-white flex items-center justify-center">
          <img
            src="/images/project1.png"
            alt="Project Preview"
            className="w-full h-full object-contain"
          />
        </div>

        {/* Project Details */}
        <div className="p-6 text-center">
          <h2 className="text-2xl font-semibold mb-2 text-blue-800">
            Ramanth School Management System
          </h2>
          <p className="text-gray-700 mb-6 leading-relaxed">
            A complete digital solution for school operations – from admissions to stock management.
          </p>

          <div className="flex flex-col md:flex-row justify-center gap-4">
            <Link
              href="https://demo-url.com"
              target="_blank"
              className="bg-blue-600 text-white px-6 py-2 rounded-full hover:bg-blue-700 transition"
            >
              View Demo
            </Link>
            <Link
              href="https://github.com/your-username/project-repo"
              target="_blank"
              className="bg-gray-300 text-gray-800 px-6 py-2 rounded-full hover:bg-gray-400 transition"
            >
              Contact For Subscription
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
