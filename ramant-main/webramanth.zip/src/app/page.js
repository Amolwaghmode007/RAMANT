'use client';
import Navbar from "./components/public/Navbar";
import { motion } from "framer-motion";
import { useLottie } from "lottie-react";
import heroAnimation from "../../src/animations/hero-animation.json";
import Services from "./services/page";
import VisionMission from "./visionpage/page";
import Projects from "./projects/page";
import AboutUs from "./about-us/page";
import ContactUs from "./contacts-us/page";
import Footer from "./footer/page";

export default function HeroSection() {
  const options = {
    animationData: heroAnimation,
    loop: true,
    autoplay: true,
    style: {
      height: 400,
      width: 400,
    },
  };

  const { View } = useLottie(options);

  return (
    <>
      <Navbar />

      {/* Hero Section */}
      <section className="min-h-screen flex items-center justify-center bg-white text-black px-6 py-20 mt-14">
        <div className="max-w-7xl w-full grid md:grid-cols-2 gap-10 items-center">
          {/* Left Text Content */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="space-y-6"
          >
            <h1 className="text-4xl md:text-6xl font-bold leading-tight text-cyan-400">
              We Build <span className="text-black">Modern</span><br />
              Web & Mobile Solutions
            </h1>
            <p className="text-black text-lg">
              From design to deployment, we help startups and businesses create stunning digital products that scale.
            </p>
          <div className="flex gap-4">
          <button className="bg-cyan-500 hover:bg-cyan-600 transition px-6 py-3 rounded-xl font-semibold">
            Explore --{'>'}
          </button>
          <button className="border border-cyan-400 hover:bg-cyan-400 hover:text-black transition px-6 py-3 rounded-xl font-semibold">
            Get Started
          </button>
        </div>
        <section className="flex gap-10 ml-4">

           <div className="text-center sm:text-left mb-4 sm:mb-0">
            <h3 className="text-2xl font-bold text-gray-900">3</h3>
            <p className="text-gray-600 text-sm">Clients</p>
          </div>
          <div className="text-center sm:text-left mb-4 sm:mb-0">
            <h3 className="text-2xl font-bold text-gray-900">4</h3>
            <p className="text-gray-600 text-sm">Projects</p>
          </div>
          <div className="text-center sm:text-left">
            <h3 className="text-2xl font-bold text-gray-900">99%</h3>
            <p className="text-gray-600 text-sm">On time delivery</p>
          </div>
  </section>

          </motion.div>

          {/* Right Lottie Animation */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="flex justify-center"
          >
            {View}
          </motion.div>
        </div>
      </section>

      <VisionMission/>

      <Services/>

      <Projects/>

      <AboutUs/>

      <ContactUs/>

      <Footer/>
      


     </>
  );
}
